LOWER_NUMBER = 33
UPPER_NUMBER = 127


def main():
    char = input("Enter a character: ")
    print("The ASCII code for {} is {}".format(char, ord(char)))
    number = int(input("Enter a number between " + str(LOWER_NUMBER) + " and " + str(UPPER_NUMBER) + ": "))
    while number < LOWER_NUMBER or number > UPPER_NUMBER:
        print("invalid number")
        number = int(input("Enter a number between " + str(LOWER_NUMBER) + " and " + str(UPPER_NUMBER) + ": "))
    print("The character for {} is {}".format(number, chr(number)))

    for i in range(LOWER_NUMBER, UPPER_NUMBER + 1, 1):
        print("{:3} {:>6}".format(i, chr(i)))
main()
