# Name        : Your Name
# Date        : 25-03-2017
# Description : This project is used to track books, change the status of the book and update the file

# This menu function is used to display the menu and get the user choice and return back to main
def menu():
    print("Menu :")
    print("R - List required books")
    print("C - List completed books")
    print("A - Add new book")
    print("M - Mark a book as completed")
    print("Q - Quit")
    return (input(">>>")).strip()

# This readFromFile function is used to load the book details from the input file
def readFromFile(fName):
    bkList=[]
    try:        
        rows=open(fName,"r")
        for row in rows:
            row=row.strip()
            if(len(row)!=0):            # check the record is empty or not
                bkList.append(row)      # add the book details into list
        rows.close()                    # close the file
        return bkList
    except :
        print("\nInvalid file name, please recheck the file name with path\n")
        return bkList
              
# This function is ised to display the required status of the books
def requiredBooks(bkList):
    num=0
    numRBooks=0
    totalPages=0
    for i in range(0,len(bkList)):
        if i==0:
            print("Required books : ")
        rows=bkList[i].split(",")
        strType=rows[3].lower()
        if strType=='r': 
            print(num,". ",rows[0].ljust(40)," by ",rows[1],"\t",rows[2]," pages")
            totalPages+=int(rows[2])
            numRBooks+=1
        num+=1
    if numRBooks==0 :
        print("\nNo required books\n")
    else:
        print("Total pages for ",numRBooks," books : ",totalPages)
        
# This function is used to display the completed status of the books
def completedBooks(bkList):
    num=0
    numCBooks=0
    totalPages=0
    for i in range(0,len(bkList)):
        if i==0:
            print("Completed books : ")
        rows=bkList[i].split(",")
        strType=rows[3].lower()
        if strType=='c': 
            print(num,". ",rows[0].ljust(40)," by ",rows[1],"\t",rows[2]," pages")
            totalPages+=int(rows[2])
            numCBooks+=1
        num+=1
    if numCBooks==0 :
        print("\nNo completed books found\n")
    else:
        print("Total pages for ",numCBooks," books : ",totalPages)
        
# This function is used to sort the book list which is ordered by book title
def sortingBkList(bkList):
    for i in range(0,len(bkList)):
        rowLineI=bkList[i].split(",")        
        for j in range (i+1,len(bkList)):
            rowLineJ=bkList[j].split(",")            
            if rowLineI[0] > rowLineJ[0] : 
                tRow=bkList[i]
                bkList[i]=bkList[j]
                bkList[j]=tRow
    return bkList

# This function is used to read the book title from user
def getTitle():
    title=""
    while True:
        try:
            title=input("Title : ")
            title=title.strip()
            if len(title) == 0:
                print("Input can not be blank")   #If user enter empty string, it displays an error message
            else:
                break
        except:
            print("Invalid data type")
    return title

# This function is used to read the book author from user
def getAuthor():
    author=""
    while True:
        try:
            author=input("Author : ")
            author=author.strip()
            if len(author) == 0:
                print("Input can not be blank")
            else:
                break
        except:
            print("Invalid data type")
    return author

# This function is used to read the page number
def getNumOfPages():
    pages=0
    while True:
        try:
            pages=int(input("Pages : "))            
            if pages<0:                         # check the input is greater than zero or not
                print("Number must be >=0")     # if user input is less than zero, it displays an error message
            else:
                break
        except:
            print("Invalid input; enter a valid number")
    return pages

#This function is used to get the number of required books from the book list
def getNumOfRequiredBooks(bkList):
    numRBooks=0    
    for i in range(0,len(bkList)):        
        rows=bkList[i].split(",")
        strType=rows[3].lower()
        if strType=='r':             
            numRBooks+=1
    return numRBooks

#This function is used to mark the required books to completed 
def markAsCompleted(bkList):
    try:        
        
        numRBooks=getNumOfRequiredBooks(bkList)    
    
        if numRBooks != 0:
            requiredBooks(bkList)
            print("Enter the number of a book to mark as completed")
            pos=int(input(">>>"))                
            num=0        
            flag=0
            
            if (pos>=0 and pos<len(bkList)) :
                print(pos)
                for i in range(0,len(bkList)):            
                    rows=bkList[i].split(",")
                    strType=rows[3].lower()
                    if strType=='r' and num==pos:                 
                        flag=1                
                    num+=1
                
                if flag==0:
                    print("That book is already completed")
                else:
                    rows=bkList[pos].split(",")
                    tBook=rows[0] +","+rows[1]+","+str(rows[2])+",c"
                    bkList[pos]=tBook
                    
                    print(rows[0]," by ",rows[1]," marked as completed")
            else:
                print("Invalid book number")
        else:
            print("No required books")
            
        return bkList
    except:
        print("Invalid input; enter a valid number")

    
   
#This is the main program    
def main():
    fileName="books.csv"
    bookList=[]
    print("Reading List 1.0 - by Lindsay Ward")     # display the welcome message
    bookList=readFromFile(fileName)
    print(len(bookList)," books loaded from ", fileName)
    userChoice=""
    
    while True:
        try:
            userChoice=menu()        
            userChoice=userChoice.lower()
            bookList=sortingBkList(bookList)
            if(userChoice=="q"):    # if user enters q, the control exits from this loop
                break
            elif (userChoice=="r"): # if user enters r, display the required books
                requiredBooks(bookList)
            elif (userChoice=="c"): # if user enters c, display the completed books
                completedBooks(bookList)
            elif (userChoice=="a"): # if user enters a, add the new books
                bkTitle=getTitle()  
                bkAuthor=getAuthor()
                bkPages=getNumOfPages()
                tBook=bkTitle +","+bkAuthor+","+str(bkPages)+",r"                
                bookList.append(tBook)  #add the new books details into book list
                print(bkTitle+" by "+ bkAuthor+", ("+str(bkPages)+") added to readling list")
            elif (userChoice=="m"):
                bookList=markAsCompleted(bookList)  # mark as completed
            else:
                print("Invalid menu choice")    # if user enter except the above choice, displays an error message
        except :
            print("Invalid entry, please retry it");
            
    sFile=open(fileName,"w")    # open a file as write mode (overwriting)
    for i in range(0,len(bookList)):
        sFile.write(bookList[i]+"\n")   #write the book details into books.csv file
    sFile.close()
    print(len(bookList)," books saved to ",fileName)
    print("\nHave a nice day :)");      # display the greeting message
        
        
main()          #Call the main function

          
