from book import Book


class BookList:
    def __init__(self, ):
        """
            Initialize an empty list for Book object
        """
        self.books = []

    def get_book(self, book_title):
        """
            Method to return a selected book object, take in a title (string) and return the Book object with that title
            this will be useful when handling book button clicking
        """
        for book in self.books:
            if book[0].book_title == book_title:
                return book[0]

    def add_book(self, book_title, book_author, book_pages):
        """
            This method handles adding a single Book object to the book list attribute
        """
        self.books.append([Book(book_title, book_author, book_pages, 'r')])

    def get_total_pages(self, book_status):
        """
            Get total pages for required books and completed books by taking in user selection as string.
            Which returns an total pages of Integer value
        """
        total_pages = 0
        for book in self.books:
            if book[0].book_status == book_status:
                total_pages = total_pages + book[0].book_pages
        return total_pages

    def load_books(self):
        """
            Load all the books from csv file into Book objects in the list
        """
        book_readfile = open('books.csv', 'r')
        for book in book_readfile:
            book_attributes = book.split(",")
            self.books.append(
                [Book(book_attributes[0], book_attributes[1], int(book_attributes[2]), book_attributes[3].strip())])

        book_readfile.close()

    def save_books(self):
        """
            Save all the books from book list into csv file
        """
        book_writefile = open('books.csv', 'w')
        for book in self.books:
            book_writefile.write(
                book[0].book_title + "," + book[0].book_author + "," + str(book[0].book_pages) + "," + book[
                    0].book_status + "\n")

        book_writefile.close()

    def sort(self):
        """
            Sort the books list by author then number of pages
        """
        self.books.sort(key=lambda i: (i[0].book_author, i[0].book_pages))
