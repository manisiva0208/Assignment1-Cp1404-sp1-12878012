class Book:
    def __init__(self, book_title, book_author, book_pages, book_status):
        """
            Initialize required attributes for a Book
        """
        self.book_title = book_title
        self.book_author = book_author
        self.book_pages = book_pages
        self.book_status = book_status

    def mark_book(self, status):
        """
            Method to mark book as completed
        """
        self.book_status = status

    def is_book_long(self):
        """
            Method to determine if the book is long (500 or more pages) and return boolean value
        """
        if self.book_pages >= 500:
            return True
        else:
            return False

    def __str__(self):
        """
            Used when displaying book details in the status bar in required book or completed book
        """
        return self.book_title + " by " + self.book_author + ", " + str(self.book_pages) + " pages (completed)"
