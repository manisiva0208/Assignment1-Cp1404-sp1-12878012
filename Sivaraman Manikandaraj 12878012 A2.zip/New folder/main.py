# Name        : Sivaraman Manikandaraj
# Date        : 15-05-2017
# Description : This project is GUI based application for assignemt Part 1 whis is to track books,
# change the status of the book and update the file

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from booklist import BookList


class ReadingList(App):
    def __init__(self, **kwargs):
        """
            Initialize all the required attributes for left layout in app.kv.
        """
        super().__init__(**kwargs)
        self.book_list = BookList()
        self.current_booklist = 'r'

        self.top_label = Label(text="Test", id="price_label")
        self.status_label = Label(text="")

        self.list_required_button = Button(text='List Required')
        self.list_completed_button = Button(text='List Completed')

        self.add_book_label = Label(text="Add New Book...")

        self.title_label = Label(text="Title:")
        self.title_textinput = TextInput(write_tab=False, multiline=False)

        self.author_label = Label(text="Author:", id="priceLabel")
        self.author_textinput = TextInput(write_tab=False, multiline=False)

        self.pages_label = Label(text="Pages:")
        self.pages_textinput = TextInput(write_tab=False, multiline=False)

        self.add_book_button = Button(text='Add Book')
        self.clear_button = Button(text='Clear')

    def build(self):
        """
            Building the Gui interface and loading the book objects form csv file and sorting them.
        """
        self.title = "Reading List 2.0"
        self.root = Builder.load_file('app.kv')
        self.book_list.load_books()
        self.book_list.sort()
        self.build_left_widgets()
        self.build_right_widgets()
        return self.root

    def build_left_widgets(self):
        """
            Placing all the attributes (Widgets) to the leftLayout mentioned in app.kv
        """
        self.root.ids.leftLayout.add_widget(self.list_required_button)
        self.root.ids.leftLayout.add_widget(self.list_completed_button)
        self.root.ids.leftLayout.add_widget(self.add_book_label)
        self.root.ids.leftLayout.add_widget(self.title_label)
        self.root.ids.leftLayout.add_widget(self.title_textinput)
        self.root.ids.leftLayout.add_widget(self.author_label)
        self.root.ids.leftLayout.add_widget(self.author_textinput)
        self.root.ids.leftLayout.add_widget(self.pages_label)
        self.root.ids.leftLayout.add_widget(self.pages_textinput)
        self.root.ids.leftLayout.add_widget(self.add_book_button)
        self.root.ids.leftLayout.add_widget(self.clear_button)

        self.root.ids.topLayout.add_widget(self.top_label)
        # Setting click state as down by default to required list when the app is launched
        self.list_required_button.state = 'down'
        self.root.ids.bottomLayout.text = "Click books to mark them as completed"
        # Setting on click for all the buttons on the leftLayout mentioned in app.kv
        self.list_required_button.bind(on_release=lambda *args: self.status_button_click('r'))
        self.list_completed_button.bind(on_release=lambda *args: self.status_button_click('c'))
        self.add_book_button.bind(on_release=self.add_book)
        self.clear_button.bind(on_release=self.clear_textfields)

    def build_right_widgets(self):
        """
            Building all the required buttons based on the Book object list dynamically and stating the color and onclick
        """
        # Getting the total pages from BookList class
        total_pages = self.book_list.get_total_pages(self.current_booklist)
        # Getting the list of objects and setting up the buttons for rightLayout in app.kv
        for book in self.book_list.books:
            # Setting up color based on required books (long or short) and completed books
            if book[0].book_status == self.current_booklist:
                book_button = Button(text=book[0].book_title)
                if not self.book_list.get_book(book[0].book_title).is_book_long() and self.current_booklist == 'r':
                    book_button.background_color = [88, 89, 0, 0.3]
                elif self.book_list.get_book(book[0].book_title).is_book_long() and self.current_booklist == 'r':
                    book_button.background_color = [0, 88, 88, 0.3]
                else:
                    book_button.background_color = [44, 44, 44, 0.2]
                # setting up onclick for each button created and adding it to rightLayout
                book_button.bind(on_release=self.book_click)
                self.root.ids.rightLayout.add_widget(book_button)

        # Displaying selected information on status bar.
        if self.current_booklist == 'r':
            self.top_label.text = "Total pages to read: " + str(total_pages)
        else:
            self.top_label.text = "Total pages completed: " + str(total_pages)

    def status_button_click(self, status):
        """
            This method handles required list or completed book button click on leftLayout
        """
        self.current_booklist = status
        # Setting the button state based on the user click and setting message accordingly on status bar
        if status == 'r':
            self.list_required_button.state = 'down'
            self.list_completed_button.state = 'normal'
            self.root.ids.bottomLayout.text = "Click books to mark them as completed"
        else:
            self.list_required_button.state = 'normal'
            self.list_completed_button.state = 'down'
            self.root.ids.bottomLayout.text = "Click books to view details"

        # Clearing the rightLayout widgets and rebuilding for updated buttons
        self.root.ids.rightLayout.clear_widgets()
        self.build_right_widgets()

    def book_click(self, button):
        """
            Handling click on rightLayout by taking the button which user clicked
        """
        if self.current_booklist == 'r':
            # Get the text of the button user clicked and marking that object on Book class as completed
            self.book_list.get_book(button.text).mark_book('c')
            self.root.ids.bottomLayout.text = "Completed: " + str(self.book_list.get_book(button.text))
            # Rebuilding the rightLayout
            self.root.ids.rightLayout.clear_widgets()
            self.build_right_widgets()
        else:
            # Just updating the status bar if they click on completed books
            self.root.ids.bottomLayout.text = str(self.book_list.get_book(button.text))

    def clear_textfields(self, *args):
        """
            This method handles clear button click and clears all the textfield
        """
        self.title_textinput.text = ""
        self.author_textinput.text = ""
        self.pages_textinput.text = ""

    def add_book(self, *args):
        """
            This method handles add book button click and handles error input and on success creates a Book object
        """
        # If any field is empty display error in status bar
        if str(self.title_textinput.text).strip() == '' or str(self.author_textinput.text).strip() == '' or str(
                self.pages_textinput.text).strip() == '':
            self.root.ids.bottomLayout.text = "All fields must be completed"
        else:
            try:
                # If the pages value is in negative display error in status bar
                if int(self.pages_textinput.text) < 0:
                    self.root.ids.bottomLayout.text = "Pages must be >= 0"
                # Else create that book object and sort accordingly and rebuld the rightLayout as changes to
                # required list
                else:
                    self.book_list.add_book(self.title_textinput.text, self.author_textinput.text,
                                            int(self.pages_textinput.text))
                    self.book_list.sort()
                    self.clear_textfields()
                    self.root.ids.rightLayout.clear_widgets()
                    self.build_right_widgets()
                    self.status_button_click('r')
            except ValueError:
                self.root.ids.bottomLayout.text = "Please enter a valid number"

    def on_stop(self):
        # When the user clicks close it saves all the data to csv file.
        self.book_list.save_books()


if __name__ == '__main__':
    app = ReadingList()
    app.run()
